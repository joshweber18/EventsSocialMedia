﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EventsMedia.Models
{
    public class Cusine
    {
        public int Cuisine_Id { get; set; }
        public string Cuisine_Name { get; set; }
    }
}
