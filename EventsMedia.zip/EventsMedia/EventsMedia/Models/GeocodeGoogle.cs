﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EventsMedia.Models
{
    public class GeocodeGoogle
    {
        public double Latitude { get; set; }
        public double Longitude { get; set; }
    }
}
